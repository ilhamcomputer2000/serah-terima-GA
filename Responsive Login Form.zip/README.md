
  # Responsive Login Form

  This is a code bundle for Responsive Login Form. The original project is available at https://www.figma.com/design/UkcPnPcu36LG41QLAZEv4n/Responsive-Login-Form.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  