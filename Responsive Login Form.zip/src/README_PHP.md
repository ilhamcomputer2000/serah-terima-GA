# Sistem Serah Terima & Pengembalian Barang - PHP Version

## 📋 Deskripsi
Aplikasi form login untuk Sistem Serah Terima & Pengembalian Barang yang dibuat dengan PHP, HTML, CSS (Tailwind), dan JavaScript vanilla.

## 🎨 Fitur
- ✅ Desain responsif dengan layout split-screen
- ✅ Tema warna orange dan putih
- ✅ Animasi interaktif (fade in, floating elements, rotating)
- ✅ Toggle show/hide password
- ✅ Remember me checkbox
- ✅ Session management
- ✅ Social login buttons (UI only)
- ✅ Dashboard setelah login berhasil

## 📁 File Structure
```
/
├── index.php          # Halaman login utama
├── dashboard.php      # Dashboard setelah login
└── README_PHP.md      # Dokumentasi ini
```

## 🚀 Cara Install & Jalankan

### Requirement
- PHP 7.4 atau lebih tinggi
- Web server (Apache/Nginx) atau PHP built-in server

### Langkah Install

1. **Download semua file**
   - Download `index.php` dan `dashboard.php`
   - Simpan dalam satu folder

2. **Jalankan dengan PHP Built-in Server**
   ```bash
   cd path/to/folder
   php -S localhost:8000
   ```

3. **Atau jalankan dengan XAMPP/WAMP**
   - Copy folder ke `htdocs` (XAMPP) atau `www` (WAMP)
   - Akses via browser: `http://localhost/nama-folder/`

4. **Buka di browser**
   ```
   http://localhost:8000/index.php
   ```

## 🔐 Login Credentials (Testing)

Untuk testing, gunakan credentials berikut:
- **Email**: admin@example.com
- **Password**: password

> ⚠️ **PENTING**: Ini hanya untuk testing! Ubah logic autentikasi di `index.php` untuk production.

## 📝 Kustomisasi

### Mengubah Warna
Edit gradien orange di `index.php`:
```css
.gradient-bg {
    background: linear-gradient(135deg, #f97316 0%, #ea580c 50%, #c2410c 100%);
}
```

### Koneksi Database
Untuk menggunakan database, ubah bagian ini di `index.php`:
```php
// Ganti bagian ini dengan query database Anda
if ($email === 'admin@example.com' && $password === 'password') {
    // Success
}
```

Contoh dengan MySQLi:
```php
$conn = new mysqli("localhost", "username", "password", "database");

$email = $conn->real_escape_string($_POST['email']);
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        header('Location: dashboard.php');
        exit();
    }
}
```

### Membuat Halaman Tambahan

Untuk membuat halaman register atau forgot password:
1. Copy struktur dari `index.php`
2. Ubah form action dan field sesuai kebutuhan
3. Tambahkan logic PHP di atas

## 🎯 Fitur yang Bisa Dikembangkan

- [ ] Integrasi dengan database MySQL/PostgreSQL
- [ ] Enkripsi password dengan password_hash()
- [ ] Email verification
- [ ] Forgot password functionality
- [ ] Form serah terima barang lengkap
- [ ] Form pengembalian barang
- [ ] Laporan & export PDF
- [ ] Multi-user roles (admin, user)
- [ ] Upload foto barang
- [ ] Barcode/QR code scanning

## 🛡️ Security Tips

1. **Selalu gunakan HTTPS di production**
2. **Hash password** dengan `password_hash()` dan verifikasi dengan `password_verify()`
3. **Validasi input** dari user untuk mencegah SQL injection
4. **Gunakan prepared statements** untuk query database
5. **Set secure session cookies**:
```php
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'],
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);
```

## 📞 Support

Jika ada pertanyaan atau butuh bantuan kustomisasi, silakan hubungi developer.

## 📄 License

Free to use for personal and commercial projects.

---

**Dibuat dengan ❤️ untuk Sistem Serah Terima & Pengembalian Barang**
